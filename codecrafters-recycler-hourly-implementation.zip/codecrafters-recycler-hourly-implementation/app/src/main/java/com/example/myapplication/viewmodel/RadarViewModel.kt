package com.example.myapplication.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.model.ForecastResponse
import com.example.myapplication.data.repository.WeatherRepository
import com.example.myapplication.model.CurrentWeatherResponse
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class RadarViewModel @Inject constructor(
    private val weatherRepository: WeatherRepository
) : ViewModel() {

    private val _weather = MutableStateFlow<WeatherEvent>(WeatherEvent.Loading)
    val weather: StateFlow<WeatherEvent> = _weather.asStateFlow()

    fun getWeather(lat: Double, lon: Double) = viewModelScope.launch {
        when (val response = weatherRepository.getWeather(lat, lon)) {
            is ForecastResponse -> _weather.value = WeatherEvent.Success(response)
            else -> _weather.value = WeatherEvent.Failure
        }
    }

    sealed class WeatherEvent {
        data class Success(val weather: CurrentWeatherResponse) : WeatherEvent()
        data object Failure : WeatherEvent()
        data object Loading : WeatherEvent()
    }
}