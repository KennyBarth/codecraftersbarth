package com.example.myapplication.ui

import android.app.SearchManager
import android.content.Intent
import android.location.Geocoder
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SearchView
import android.widget.TextView
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.myapplication.databinding.FragmentDailyBinding
import com.example.myapplication.databinding.FragmentWeatherBinding
import com.example.myapplication.model.CurrentWeatherResponse
import com.example.myapplication.viewmodel.DailyViewModel
import com.example.myapplication.viewmodel.WeatherViewModel
import android.content.Context
import kotlinx.coroutines.launch
import java.lang.Exception
import java.util.Locale

class DailyFragment : Fragment() {

    private var _binding: FragmentDailyBinding? = null

    private val binding get() = _binding!!
    private lateinit var geocoder: Geocoder
    private val dailyViewModel: DailyViewModel by activityViewModels()


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDailyBinding.inflate(inflater, container, false)
        setupObservers()

        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                query?.let { searchQuery ->
                    val geocoder = context?.let { Geocoder(it, Locale.getDefault()) }

                    try {
                        val addressList = geocoder?.getFromLocationName(searchQuery, 1)
                        if (!addressList.isNullOrEmpty()) {
                            val latitude = addressList[0].latitude
                            val longitude = addressList[0].longitude
                            dailyViewModel.getWeather(latitude, longitude)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
                return true
            }
            override fun onQueryTextChange(newText: String?): Boolean {
                // fix
                return true
            }
        })

        return binding.root
    }





    fun setupObservers() {
        lifecycleScope.launch {
            dailyViewModel.weather.collect { event ->
                when (event) {
                    DailyViewModel.WeatherEvent.Failure -> {
                        setVisible(false)
                        binding.progressBarCurrent.isVisible = false
                        binding.errorMessageCurrent.isVisible = true
                    }
                    DailyViewModel.WeatherEvent.Loading -> {
                        setVisible(false)
                        binding.progressBarCurrent.isVisible = true
                        binding.errorMessageCurrent.isVisible = false
                    }
                    is DailyViewModel.WeatherEvent.Success -> {
                        setData(event.weather)
                        setVisible(true)
                        binding.progressBarCurrent.isVisible = false
                        binding.errorMessageCurrent.isVisible = false
                    }
                }
            }
        }
    }

    fun setVisible(visible: Boolean) {
        binding.textWeatherTemp.isVisible = visible
        binding.textWeather.isVisible = visible
        binding.textWeather2.isVisible = visible
        binding.textWeatherSpeed.isVisible = visible
    }
    fun setData(weather: CurrentWeatherResponse) {
        binding.textWeatherTemp.text = weather.main.temp.toString()
        binding.textWeather.text = weather.main.humidity.toString()
        binding.textWeather2.text = weather.main.feelsLike.toString()
        binding.textWeatherSpeed.text = weather.wind.speed.toString()

    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}