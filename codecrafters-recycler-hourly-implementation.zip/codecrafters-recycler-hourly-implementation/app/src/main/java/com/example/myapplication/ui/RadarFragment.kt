package com.example.myapplication.ui

import android.content.pm.PackageManager
import android.location.Geocoder
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SearchView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.databinding.FragmentWeatherBinding
import com.example.myapplication.model.CurrentWeatherResponse
import com.example.myapplication.model.ForecastResponse
import com.example.myapplication.ui.adapter.RadarAdapter
import com.example.myapplication.viewmodel.RadarViewModel
import com.example.myapplication.viewmodel.WeatherViewModel
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.util.Locale

class RadarFragment : Fragment() {

    private var _binding: FragmentWeatherBinding? = null

    private val binding get() = _binding!!

    private val radarViewModel: RadarViewModel by activityViewModels()

    private lateinit var geocoder: Geocoder
    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentWeatherBinding.inflate(inflater, container, false)
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(requireContext().applicationContext)
        geocoder = Geocoder(requireContext().applicationContext, Locale.getDefault())

        setupObservers()
        getLastLocation()

        return binding.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        setupObservers()
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun setupRecyclerView() {
        val radarAdapter = RadarAdapter()
        binding.recyclerViewForecast.apply {
            val adapter = radarAdapter
            val layoutManager = LinearLayoutManager(requireContext())
        }
    }



    fun setupObservers() {
        lifecycleScope.launch {
            radarViewModel.weather.collect { event ->
                when (event) {
                    RadarViewModel.WeatherEvent.Failure -> {
                        setVisible(false)
                        binding.progressBarCurrent.isVisible = false
                        binding.errorMessageCurrent.isVisible = true
                    }
                    RadarViewModel.WeatherEvent.Loading -> {
                        setVisible(false)
                        binding.progressBarCurrent.isVisible = true
                        binding.errorMessageCurrent.isVisible = false
                    }
                    is RadarViewModel.WeatherEvent.Success -> {
                        setData(event.weather)
                        setVisible(true)
                        binding.progressBarCurrent.isVisible = false
                        binding.errorMessageCurrent.isVisible = false
                    }
                }
            }
        }
    }

    fun setVisible(visible: Boolean) {
        binding.textWeatherTemp.isVisible = visible
        binding.textWeather.isVisible = visible
        binding.textWeather2.isVisible = visible
        binding.textWeatherSpeed.isVisible = visible
    }

    fun setData(weather: ForecastResponse) {

        val temperature = weather.list.firstOrNull()?.main?.temp ?: 0.0
        binding.textWeatherTemp.text = temperature.toString()

        val weatherDescription = weather.list.firstOrNull()?.weather?.firstOrNull()?.description ?: ""
        binding.textWeather.text = weatherDescription

        val windSpeed = weather.list.firstOrNull()?.wind?.speed ?: 0.0
        binding.textWeatherSpeed.text = windSpeed.toString()
    }


    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun getLastLocation() {
        if (ActivityCompat.checkSelfPermission(
                requireContext(),
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                requireContext(),
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                requireActivity(),
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION),
                10101)
        }

        val lastLocation = fusedLocationProviderClient.lastLocation

        lastLocation.addOnSuccessListener {
            radarViewModel.getWeather(it.latitude, it.longitude)
        }
        lastLocation.addOnFailureListener {
            Toast.makeText(requireContext(), "Getting Location Failed", Toast.LENGTH_LONG).show()
        }
    }
}