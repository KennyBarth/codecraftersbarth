package com.example.myapplication.ui.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class RadarAdapter {
    private val onCharacterClicked: (character: AnimeCharacter1.Data, position: Int) -> Unit,
    ) : RecyclerView.Adapter<AnimeCharacterAdapter.AnimeCharacterViewHolder>() {

        inner class AnimeCharacterViewHolder(
            private val binding: CharacterCardViewBinding,
            private val onCharacterClicked: (position: Int) -> Unit
        ) : RecyclerView.ViewHolder(binding.root) {

            init {
                itemView.setOnClickListener {
                    onCharacterClicked(adapterPosition)
                }
            }

            fun bind(character: AnimeCharacter1.Data) {
                binding.characterTitle.text = binding.root.context.getString(R.string.character_name, character.name)
                binding.characterFilms.text = binding.root.context.getString(R.string.character_films, character.films.joinToString())
                Glide.with(binding.root).load(character.imageUrl).into(binding.characterImage)
            }
        }

        private val animeCharacters = mutableListOf<AnimeCharacter1.Data>()

        @SuppressLint("NotifyDataSetChanged")
        fun refreshData(characters: List<AnimeCharacter1.Data>) {
            animeCharacters.clear()
            animeCharacters.addAll(characters)
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(
            parent: ViewGroup,
            viewType: Int,
        ): AnimeCharacterViewHolder {
            val binding =
                CharacterCardViewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return AnimeCharacterViewHolder(binding) { position ->
                onCharacterClicked(animeCharacters[position], position)
            }
        }

        override fun getItemCount() = animeCharacters.size

        override fun getItemId(position: Int) = position.toLong()

        override fun onBindViewHolder(holder: AnimeCharacterViewHolder, position: Int) {
            val character = animeCharacters[position]
            holder.bind(character)
        }
    }
}