package com.example.myapplication.data.model

import com.example.myapplication.model.CurrentWeatherResponse
import com.example.myapplication.model.ForecastResponse

sealed class WeatherResponseCurrent {
    data class Success(val weather : CurrentWeatherResponse) : WeatherResponseCurrent()
    data object Error : WeatherResponseCurrent()
}

sealed class WeatherResponseForecast {
    data class Success(val forecast : List<ForecastResponse.Forecast>) : WeatherResponseForecast()
    data object Error : WeatherResponseForecast()
}