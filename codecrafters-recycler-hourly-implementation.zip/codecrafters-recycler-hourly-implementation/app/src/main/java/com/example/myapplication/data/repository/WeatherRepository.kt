package com.example.myapplication.data.repository

import com.example.myapplication.data.model.WeatherResponseForecast
import com.example.myapplication.data.model.WeatherResponseCurrent
import com.example.myapplication.model.ForecastResponse

interface WeatherRepository {
    suspend fun getWeather(lat: Double, lon: Double) : WeatherResponseCurrent

    suspend fun getForecast(lat: Double, lon: Double): WeatherResponseForecast
}